import { useLocation, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import DashboardHeader from '../../components/layout/DashboardHeader';
import '../../styles/design-system.css';
import '../../styles/components.css';
import '../../styles/layout.css';
import './exam.css';

export default function ExamResult() {
  const { state } = useLocation();
  const navigate = useNavigate();

  // Guard: redirect if no state
  useEffect(() => {
    if (!state?.questions) navigate('/exam');
  }, [state, navigate]);

  if (!state?.questions) return null;

  const { answers = {}, questions, auto = false } = state;

  // Calculate scores
  let correct = 0, wrong = 0, skipped = 0;
  questions.forEach((q, idx) => {
    if (answers[idx] === undefined) {
      skipped++;
    } else if (answers[idx] === q.correct) {
      correct++;
    } else {
      wrong++;
    }
  });

  const total = questions.length;
  const score = correct;
  const percentage = Math.round((correct / total) * 100);
  const passed = percentage >= 60;

  const now = new Date();

  const getRank = () => {
    if (percentage >= 90) return { label: 'Excellent', color: '#16a34a', bg: '#dcfce7', icon: '🏆' };
    if (percentage >= 75) return { label: 'Good', color: '#2563eb', bg: '#dbeafe', icon: '🎯' };
    if (percentage >= 60) return { label: 'Average', color: '#d97706', bg: '#fef3c7', icon: '📈' };
    return { label: 'Needs Improvement', color: '#dc2626', bg: '#fee2e2', icon: '📚' };
  };

  const rank = getRank();

  return (
    <div className="dash-shell">
      <DashboardHeader />
      <div className="dash-main">
        <div className="dash-content">
          <div className="result-shell">
            {/* Header Card */}
            <div className="result-hero">
              {auto && (
                <div className="result-auto-badge">⏰ Time's up — Auto submitted</div>
              )}
              <div className="result-rank-badge" style={{ background: rank.bg, color: rank.color }}>
                <span>{rank.icon}</span> {rank.label}
              </div>
              <h1 className="result-title">Test Completed!</h1>
              <p className="result-subtitle">Legal Aptitude — Practice Set 1</p>
              <div className="result-date">
                {now.toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })} &nbsp;·&nbsp;
                {now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
              </div>

              {/* Score Circle */}
              <div className="result-score-wrap">
                <div className="result-score-circle" style={{
                  '--pct': percentage,
                  '--color': rank.color
                }}>
                  <div className="result-score-inner">
                    <span className="result-score-num">{score}</span>
                    <span className="result-score-total">/{total}</span>
                    <span className="result-score-pct">{percentage}%</span>
                  </div>
                </div>
              </div>

              {/* Stats Row */}
              <div className="result-stats-row">
                <div className="result-stat correct">
                  <span className="rs-icon">✅</span>
                  <span className="rs-val">{correct}</span>
                  <span className="rs-label">Correct</span>
                </div>
                <div className="result-stat wrong">
                  <span className="rs-icon">❌</span>
                  <span className="rs-val">{wrong}</span>
                  <span className="rs-label">Wrong</span>
                </div>
                <div className="result-stat skipped">
                  <span className="rs-icon">⏭</span>
                  <span className="rs-val">{skipped}</span>
                  <span className="rs-label">Skipped</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="result-actions">
              <button className="btn btn-secondary" onClick={() => navigate('/exam')}>
                ← Back to Exams
              </button>
              <button className="btn btn-primary" onClick={() => navigate('/exam/mock-test')}>
                Retake Test
              </button>
            </div>

            {/* Detailed Review */}
            <div className="result-review">
              <h2 className="result-review-title">Detailed Review</h2>
              <div className="result-q-list">
                {questions.map((q, idx) => {
                  const userAns = answers[idx];
                  const isCorrect = userAns === q.correct;
                  const isSkipped = userAns === undefined;
                  let status = isSkipped ? 'skipped' : isCorrect ? 'correct' : 'wrong';
                  return (
                    <div key={q.id} className={`result-q-item ${status}`}>
                      <div className="result-q-top">
                        <span className={`result-q-badge ${status}`}>
                          {status === 'correct' ? '✅ Correct' : status === 'wrong' ? '❌ Wrong' : '⏭ Skipped'}
                        </span>
                        <span className="result-q-num">Q{idx + 1}</span>
                      </div>
                      <p className="result-q-text">{q.question}</p>
                      <div className="result-q-options">
                        {q.options.map((opt, i) => {
                          let cls = 'result-opt';
                          if (i === q.correct) cls += ' correct-ans';
                          if (i === userAns && !isCorrect) cls += ' wrong-ans';
                          return (
                            <div key={i} className={cls}>
                              <span className="result-opt-label">{String.fromCharCode(65 + i)}</span>
                              <span className="result-opt-text">{opt}</span>
                              {i === q.correct && <span className="result-opt-tag correct">✓ Correct</span>}
                              {i === userAns && !isCorrect && <span className="result-opt-tag wrong">✗ Your Answer</span>}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
