import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import DashboardHeader from '../../components/layout/DashboardHeader';
import '../../styles/design-system.css';
import '../../styles/components.css';
import '../../styles/layout.css';
import './exam.css';

const MOCK_QUESTIONS = [
  {
    id: 1,
    question: 'Which Article of the Indian Constitution abolishes untouchability?',
    options: ['Article 14', 'Article 17', 'Article 21', 'Article 25'],
    correct: 1,
  },
  {
    id: 2,
    question: 'The concept of "Basic Structure Doctrine" was introduced in which landmark case?',
    options: ['Golaknath v. State of Punjab', 'Kesavananda Bharati v. State of Kerala', 'Maneka Gandhi v. Union of India', 'Minerva Mills v. Union of India'],
    correct: 1,
  },
  {
    id: 3,
    question: 'Under the Indian Penal Code, the maximum punishment for murder (Section 302) is:',
    options: ['Life imprisonment', 'Death penalty or life imprisonment', '20 years rigorous imprisonment', 'Death penalty only'],
    correct: 1,
  },
  {
    id: 4,
    question: 'Which of the following is NOT a Fundamental Right under Part III of the Indian Constitution?',
    options: ['Right to Equality', 'Right to Freedom', 'Right to Property', 'Right against Exploitation'],
    correct: 2,
  },
  {
    id: 5,
    question: 'The doctrine of "Res Judicata" is enshrined in which section of the Code of Civil Procedure, 1908?',
    options: ['Section 9', 'Section 10', 'Section 11', 'Section 13'],
    correct: 2,
  },
  {
    id: 6,
    question: 'In which year was the Right to Information Act enacted in India?',
    options: ['2003', '2004', '2005', '2006'],
    correct: 2,
  },
  {
    id: 7,
    question: 'A contract without consideration is generally:',
    options: ['Valid', 'Voidable', 'Void', 'Illegal'],
    correct: 2,
  },
  {
    id: 8,
    question: 'The principle of "Audi Alteram Partem" means:',
    options: ['Hear both sides', 'No one shall be judge in his own cause', 'Act in good faith', 'Natural justice'],
    correct: 0,
  },
  {
    id: 9,
    question: 'Which Schedule of the Indian Constitution contains the Anti-Defection Law?',
    options: ['8th Schedule', '9th Schedule', '10th Schedule', '11th Schedule'],
    correct: 2,
  },
  {
    id: 10,
    question: 'Under the Indian Evidence Act, 1872, the burden of proof lies on:',
    options: ['The defendant always', 'The party who asserts the fact', 'The prosecution always', 'The judge to determine'],
    correct: 1,
  },
];

const TOTAL_SECS = 30 * 60; // 30 minutes

export default function MockTest() {
  const navigate = useNavigate();
  const { examId } = useParams();
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({}); // { questionId: optionIndex }
  const [flagged, setFlagged] = useState(new Set());
  const [secs, setSecs] = useState(TOTAL_SECS);
  const [showConfirm, setShowConfirm] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setSecs(s => {
        if (s <= 1) {
          clearInterval(timerRef.current);
          handleAutoSubmit();
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, []);

  const formatTime = s => {
    const m = String(Math.floor(s / 60)).padStart(2, '0');
    const sc = String(s % 60).padStart(2, '0');
    return `${m}:${sc}`;
  };

  const isExpiring = secs <= 300;

  const selectAnswer = (qIdx, optIdx) => {
    setAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const toggleFlag = qIdx => {
    setFlagged(prev => {
      const next = new Set(prev);
      next.has(qIdx) ? next.delete(qIdx) : next.add(qIdx);
      return next;
    });
  };

  const handleAutoSubmit = () => {
    clearInterval(timerRef.current);
    navigate('/exam/result', { state: { answers, questions: MOCK_QUESTIONS, auto: true } });
  };

  const handleSubmit = () => {
    clearInterval(timerRef.current);
    setShowConfirm(false);
    navigate('/exam/result', { state: { answers, questions: MOCK_QUESTIONS, auto: false } });
  };

  const getStatus = idx => {
    if (idx === current) return 'current';
    if (answers[idx] !== undefined && flagged.has(idx)) return 'answered-flagged';
    if (answers[idx] !== undefined) return 'answered';
    if (flagged.has(idx)) return 'flagged';
    return 'unattempted';
  };

  const answered = Object.keys(answers).length;
  const unattempted = MOCK_QUESTIONS.length - answered;

  const q = MOCK_QUESTIONS[current];

  return (
    <div className="dash-shell">
      <DashboardHeader />
      <div className="dash-main">
        {/* Exam Top Bar */}
        <div className="exam-topbar">
          <div className="exam-topbar-title">
            <span className="exam-topbar-badge">MOCK TEST</span>
            <span className="exam-topbar-name">Legal Aptitude — Practice Set 1</span>
          </div>
          <div className={`exam-timer ${isExpiring ? 'expiring' : ''}`}>
            <span className="exam-timer-icon">⏱</span>
            <span className="exam-timer-val">{formatTime(secs)}</span>
          </div>
          <button className="btn btn-primary exam-submit-btn" onClick={() => setShowConfirm(true)}>
            Submit Test
          </button>
        </div>

        <div className="exam-shell">
          {/* LEFT: Question Navigator */}
          <aside className="exam-sidebar">
            <div className="exam-sidebar-head">
              <div className="exam-sidebar-title">Questions</div>
              <div className="exam-sidebar-stats">
                <span className="stat-pill answered">{answered} Answered</span>
                <span className="stat-pill unattempted">{unattempted} Left</span>
                {flagged.size > 0 && <span className="stat-pill flagged">{flagged.size} Flagged</span>}
              </div>
            </div>
            <div className="exam-q-grid">
              {MOCK_QUESTIONS.map((_, idx) => (
                <button
                  key={idx}
                  className={`exam-q-btn ${getStatus(idx)}`}
                  onClick={() => setCurrent(idx)}
                  title={`Question ${idx + 1}`}
                >
                  {idx + 1}
                  {flagged.has(idx) && <span className="q-flag-dot" />}
                </button>
              ))}
            </div>
            <div className="exam-legend">
              <div className="legend-item"><span className="legend-dot answered" />Answered</div>
              <div className="legend-item"><span className="legend-dot unattempted" />Not Answered</div>
              <div className="legend-item"><span className="legend-dot flagged" />Flagged</div>
              <div className="legend-item"><span className="legend-dot current" />Current</div>
            </div>
          </aside>

          {/* RIGHT: Question Detail */}
          <main className="exam-main">
            <div className="exam-q-card">
              <div className="exam-q-header">
                <div className="exam-q-num">Q{current + 1} <span className="exam-q-of">/ {MOCK_QUESTIONS.length}</span></div>
                <button
                  className={`exam-flag-btn ${flagged.has(current) ? 'active' : ''}`}
                  onClick={() => toggleFlag(current)}
                >
                  {flagged.has(current) ? '🚩 Flagged' : '⚑ Flag'}
                </button>
              </div>

              <p className="exam-q-text">{q.question}</p>

              <div className="exam-options">
                {q.options.map((opt, i) => (
                  <button
                    key={i}
                    className={`exam-option ${answers[current] === i ? 'selected' : ''}`}
                    onClick={() => selectAnswer(current, i)}
                  >
                    <span className="exam-option-label">{String.fromCharCode(65 + i)}</span>
                    <span className="exam-option-text">{opt}</span>
                  </button>
                ))}
              </div>

              <div className="exam-q-nav">
                <button
                  className="btn btn-secondary"
                  onClick={() => setCurrent(p => Math.max(0, p - 1))}
                  disabled={current === 0}
                >
                  ← Previous
                </button>
                {answers[current] !== undefined && (
                  <button
                    className="exam-clear-btn"
                    onClick={() => setAnswers(prev => { const n = { ...prev }; delete n[current]; return n; })}
                  >
                    Clear Answer
                  </button>
                )}
                <button
                  className="btn btn-primary"
                  onClick={() => setCurrent(p => Math.min(MOCK_QUESTIONS.length - 1, p + 1))}
                  disabled={current === MOCK_QUESTIONS.length - 1}
                >
                  Next →
                </button>
              </div>
            </div>
          </main>
        </div>
      </div>

      {/* Submit Confirmation Modal */}
      {showConfirm && (
        <div className="exam-modal-overlay">
          <div className="exam-modal">
            <div className="exam-modal-icon">📋</div>
            <h3>Submit Test?</h3>
            <p>You're about to submit your test. This action cannot be undone.</p>
            <div className="exam-modal-stats">
              <div className="modal-stat">
                <span className="modal-stat-val answered">{answered}</span>
                <span className="modal-stat-label">Answered</span>
              </div>
              <div className="modal-stat">
                <span className="modal-stat-val unattempted">{unattempted}</span>
                <span className="modal-stat-label">Unattempted</span>
              </div>
              <div className="modal-stat">
                <span className="modal-stat-val flagged">{flagged.size}</span>
                <span className="modal-stat-label">Flagged</span>
              </div>
            </div>
            {unattempted > 0 && (
              <div className="exam-modal-warn">
                ⚠️ You have {unattempted} unattempted question{unattempted > 1 ? 's' : ''}. Are you sure?
              </div>
            )}
            <div className="exam-modal-actions">
              <button className="btn btn-secondary" onClick={() => setShowConfirm(false)}>Review More</button>
              <button className="btn btn-primary" onClick={handleSubmit}>Submit Now</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
